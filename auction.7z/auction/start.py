import threading
import time
from datetime import datetime
import telebot
import sqlite3 as sl
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
bot = telebot.TeleBot('6298141799:AAFYiDjCRa0roPxLUihq-FQz47koqRetwf0')
con = sl.connect("auction.db")
channel_id = "-1001900076343"


def f1():
    import bot
t1 = threading.Thread(target = f1)
t1.start()

def publish(lot_id):
    admin_info = con.execute(f"SELECT info FROM ADMINS WHERE id = (SELECT seller_id FROM LOTS WHERE id = {lot_id})").fetchone()[0]
    description = con.execute(f"SELECT description FROM LOTS WHERE id = {lot_id}").fetchone()[0]
    geo = con.execute(f"SELECT geo FROM LOTS WHERE id = {lot_id}").fetchone()[0]
    start_price = con.execute(f"SELECT start_price FROM LOTS WHERE id = {lot_id}").fetchone()[0]
    lot_keyb = InlineKeyboardMarkup()
    lot_keyb.add(InlineKeyboardButton("Участвовать", url=f"http://t.me/certification_auction_bot?start={lot_id}"))
    lot_keyb.row(InlineKeyboardButton("🕐", callback_data=f"c{lot_id}"), InlineKeyboardButton("ℹ️", callback_data="a"))
    message = f"{description}\n{geo}\nОплата {admin_info}\n💰Старт - {start_price}₽"
    with open(f"images/{lot_id}.jpg", "rb") as image:
        bot.send_photo(channel_id, photo=image, caption=message, reply_markup=lot_keyb)

while True:
    lots = []
    now = datetime.now()
    with con:
        #сначала проверить есть ли лоты для публикации прямо сейчас
        to_bublish_now = con.execute("SELECT EXISTS(SELECT id FROM LOTS WHERE status_id = 2 AND start_time IS NULL)").fetchone()[0]
        if to_bublish_now:
            lots_to_publish_now = con.execute("SELECT id FROM LOTS WHERE status_id = 2 AND start_time IS NULL").fetchall()
            for x in lots_to_publish_now:
                lot_id = x[0]
                end_time = con.execute(f"SELECT end_time FROM LOTS WHERE id = {lot_id}").fetchone()[0]
                end_time = datetime.strptime(end_time, "%d.%m.%Y %H:%M")
                if now < end_time:
                    con.execute(f"UPDATE LOTS SET start_time = '{now.strftime('%d.%m.%Y %H:%M')}', status_id = 3 WHERE id = {lot_id}")
                    publish(lot_id)
        else:
            # затем проверить не пришло ли время для публикации лота, отложенного на время
            to_publist_later = con.execute("SELECT EXISTS (SELECT id FROM LOTS WHERE status_id = 2 AND start_time IS NOT NULL)").fetchone()[0]
            if to_publist_later:
                lots_to_publish_later = con.execute("SELECT id FROM LOTS WHERE status_id = 2 AND start_time IS NOT NULL").fetchall()
                for x in lots_to_publish_later:
                    lot_id = x[0]
                    end_time = con.execute(f"SELECT end_time FROM LOTS WHERE id = {lot_id}").fetchone()[0]
                    end_time = datetime.strptime(end_time, "%d.%m.%Y %H:%M")
                    start_time = con.execute(f"SELECT start_time FROM LOTS WHERE id = {lot_id}").fetchone()[0]
                    start_time = datetime.strptime(start_time, "%d.%m.%Y %H:%M")
                    if now < start_time and now < end_time:
                        con.execute(f"UPDATE LOTS SET status_id = 3 WHERE id = {lot_id}")
                        publish(lot_id)
        to_finish_now = con.execute("SELECT EXISTS (SELECT id FROM LOTS WHERE status_id = 3)").fetchone()[0]
        if to_finish_now:
            lots_to_finish_now = con.execute("SELECT id FROM LOTS WHERE status_id = 3").fetchall()
            for x in lots_to_finish_now:
                start_price = con.execute(f"SELECT start_price FROM LOTS WHERE id = {lot_id}").fetchone()[0]
                current_price = con.execute(f"SELECT MAX(current_bet) FROM TRADE_HIST WHERE lot_id = {lot_id}").fetchone()[0]
                con.execute(f"UPDATE LOTS SET status_id = 4 WHERE id = {lot_id}")
    time.sleep(10)