import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import sqlite3 as sl
from datetime import datetime
import locale
locale.setlocale(locale.LC_ALL, "")

con = sl.connect("auction.db", check_same_thread=False)
bot = telebot.TeleBot('6298141799:AAFYiDjCRa0roPxLUihq-FQz47koqRetwf0')
channel_id = "-1001900076343"

account_menu = InlineKeyboardMarkup()
account_menu.add(InlineKeyboardButton("Баланс", callback_data="b"))
account_menu.add(InlineKeyboardButton("Мои аукционы", callback_data="m"))
account_menu.add(InlineKeyboardButton("Розыгрыш Рублевика Екатерины 2", callback_data="d"))
account_menu.add(InlineKeyboardButton("Топ пользователей", callback_data="t"))
account_menu.add(InlineKeyboardButton("Правила", callback_data="r"))
account_menu.add(InlineKeyboardButton("Статистика", callback_data="s"))
account_menu.add(InlineKeyboardButton("Помощь", callback_data="h"))

return_button = InlineKeyboardMarkup()
return_button.add(InlineKeyboardButton("Главное меню", callback_data="*"))

start_message = "Привет ,я бот аукционов @auction_pathfree\nЯ помогу вам следить за выбранными лотами ," \
          "и регулировать\nход аукциона.А так же буду следить за вашими накопленными\nбалами.\nУдачных торгов 🤝"


@bot.message_handler(content_types=['text'])
def start(message):
    user_id = message.from_user.id
    name = message.from_user.first_name
    if message.text == '/start':
        bot.send_message(user_id, start_message, reply_markup=account_menu)
        with con:
            con.execute(f"INSERT OR IGNORE INTO USERS (tg_id, name) VALUES ({user_id}, '{name}')")
    elif message.text[0:6] == "/start":
        lot_id = int(message.text[7:])
        with con:
            con.execute(f"INSERT OR IGNORE INTO USERS (tg_id, name) VALUES ({user_id}, '{name}')")
            description = con.execute(f"SELECT description FROM LOTS WHERE id = {lot_id}").fetchone()[0]
            geo = con.execute(f"SELECT geo FROM LOTS WHERE id = {lot_id}").fetchone()[0]
            admin_info = con.execute(f"SELECT info FROM ADMINS WHERE id = (SELECT seller_id FROM LOTS WHERE id = {lot_id})").fetchone()[0]
            start_price = con.execute(f"SELECT start_price FROM LOTS WHERE id = {lot_id}").fetchone()[0]
        message = f"{description}\n{geo}\nОплата {admin_info}\n💰Старт - {start_price}₽"
        lot_keyb = InlineKeyboardMarkup()
        lot_keyb.row(
            InlineKeyboardButton("+30₽", callback_data=f"+ {lot_id} 30"),
            InlineKeyboardButton("+50₽", callback_data=f"+ {lot_id} 50"),
            InlineKeyboardButton("+100₽", callback_data=f"+ {lot_id} 100")
        )
        lot_keyb.row(
            InlineKeyboardButton("+300₽", callback_data=f"+ {lot_id} 300"),
            InlineKeyboardButton("+500₽", callback_data=f"+ {lot_id} 500")
        )
        lot_keyb.add(InlineKeyboardButton("Старт", callback_data=f"g {lot_id}"))
        lot_keyb.add(InlineKeyboardButton("Авто-ставка", callback_data=f"u {lot_id}"))
        with open(f"images/{lot_id}.jpg","rb") as image:
            bot.send_photo(user_id, photo=image, caption=message, reply_markup=lot_keyb)


@bot.callback_query_handler(func=lambda call: True)
def query_handler(call):
    flag = call.data[0]
    message_id = call.message.message_id
    chat_id = call.message.chat.id

    if flag == "*":
        bot.edit_message_text(message_id=message_id, chat_id=chat_id, text=start_message ,reply_markup=account_menu)

    if flag == "b":
        with con:
            balance = con.execute(f"SELECT balance FROM USERS WHERE tg_id = {chat_id}").fetchone()[0]
        bot.edit_message_text(message_id=message_id, chat_id=chat_id, text=f"Ваш баланс: {balance}₽", reply_markup=return_button)

    if flag == "m":
        with con:
            trades_list = con.execute(f"SELECT MAX(current_bet), description, lot_id FROM TRADE_HIST "
                                      f"JOIN LOTS ON LOTS.id = TRADE_HIST.lot_id WHERE buyer_id = "
                                      f"(SELECT id FROM USERS WHERE tg_id = {chat_id})"
                                      f"GROUP BY lot_id").fetchall()
            if trades_list:
                message = "Аукционы в которых вы выиграли"
                wins = InlineKeyboardMarkup()
                for x in trades_list:
                    wins.add(InlineKeyboardButton(f"\n{x[0]}₽ {x[1]}", callback_data="l" + x[2]))
                wins.add(InlineKeyboardButton("На главную", callback_data="*"))
                bot.edit_message_text(message_id=message_id, chat_id=chat_id, text=message, reply_markup=wins)
            else:
                message = "Вы не выиграли ещё ни в одном из аукционов"
                bot.edit_message_text(message_id=message_id, chat_id=chat_id, text=message, reply_markup=return_button)

    if flag == "d":
        bot.edit_message_text(message_id=message_id, chat_id=chat_id, text=
"""
‼️Внимание Розыгрыш‼️
Общий призовой фонд 66000₽🔥

 Конкурс рассчитан на вашу активность,за каждую ставку и выигранный лот с аукционов @auction_pathfree вам будут начисляться бонусные баллы:

      Победная                Кол-во баллов 
        Ставка :          за  этот лот:
     0 - 249₽          -       1️⃣0️⃣ баллов
  250 - 499₽        -       2️⃣0️⃣ баллов
  500 - 999₽        -       3️⃣0️⃣ баллов
1000 - 1999₽      -       5️⃣0️⃣ баллов
2000 - 4999₽     -       1️⃣5️⃣0️⃣ баллов 
5000 - 9999₽     -       3️⃣0️⃣0️⃣ баллов
 от 10000₽        -       5️⃣0️⃣0️⃣ баллов
 от 20000₽      -   1️⃣0️⃣0️⃣0️⃣баллов
 от 30000₽      -   2️⃣0️⃣0️⃣0️⃣баллов
          Обычная ставка +3 балла

     Подсчёт баллов будет каждый день,после окончания аукциона,бот автоматически будет вносить изменения в таблицу участников.
Контролировать бонусные балы,можно будет самостоятельно в личном кабинете бота.

Дата проведения 25.09.21 - 31.10.21
Итоги подведём 31 Октября.
ГЛАВНЫЙ ПРИЗ - Рубль Екатерины 
1770 СПБ ЯЧ
2 Место - Рубль Масон 1829 СПБ НГ
3 Место - 5 копеек 1912 MS61
4 Место - 5 копеек 1863 ЕМ
5 Место - 2 марки 1906г.Вюртемберг
6 Место - 50 копеек 1922 MS62
7 Место - 15 копеек 1916 MS63
8 Место - Копейка 1915 MS63
9 Место - 1 Флорин 1886г
10 Место - 5 Марок Третий Рейх
11 Место - 50 коп 1926
12 Место - 50 коп 1924

Удачных торгов и выгодных покупок.""", reply_markup=return_button)

    if flag == "t":
        with con:
            users_list = con.execute("SELECT substr(name, 1, 3) AS name, points FROM USERS ORDER BY points "
                                     "DESC LIMIT 20").fetchall()
        message = "Таблица обновляется каждый день в 23:30 по МСК."
        i = 0
        for x in users_list:
            i += 1
            message += f"\n{1}) {x[0]} ***|Баллов:{x[1]}"
        bot.edit_message_text(message_id=message_id, chat_id=chat_id, text=message, reply_markup=return_button)

    if flag == "r":
        bot.edit_message_text(message_id=message_id, chat_id=chat_id, text=
"""
После окончания торгов,победитель или продавец должены выйти на связь в течении суток‼️
Победитель обязан выкупить лот в течении ТРЁХ дней,после окончания аукциона🔥
НЕ ВЫКУП ЛОТА - ПЕРМАНЕНТНЫЙ БАН ВО ВСЕХ НУМИЗМАТИЧЕСКИХ СООБЩЕСТВАХ И АУКЦИОНАХ🤬
Что бы узнать время окончания аукциона,нажмите на ⏰
Антиснайпер - Ставка сделанная за 5 минут до конца,автоматически переносит
Аукцион на 5 минут вперёд ‼️

Работают только проверенные продавцы.
Дополнительные Фото можно запросить у продавца.
Случайно сделал ставку?🤔
Напиши продавцу‼️


Отправка почтой,стоимость пересылки зависит от общего веса отправления и страны. Обсуждается с продавцом. 
Лоты можно копить ,экономя при этом на почте.
Отправка в течении трёх дней после оплаты‼️""", reply_markup=return_button)

    if flag == "s":
        with con:
            auction_count = con.execute(f"SELECT COUNT(DISTINCT(lot_id)) FROM TRADE_HIST "
                                        f"WHERE buyer_id = (SELECT id FROM USERS WHERE tg_id = {chat_id})").fetchone()[0]
            bets_count = con.execute(f"SELECT COUNT(current_bet) FROM TRADE_HIST "
                                     f"WHERE buyer_id = (SELECT id FROM USERS WHERE tg_id = {chat_id})").fetchone()[0]
            wins_count = con.execute(f"SELECT COUNT(*) FROM LOTS JOIN TRADE_HIST ON TRADE_HIST.lot_id = LOTS. id "
                                     f"WHERE is_sold = 1 AND buyer_id = (SELECT id FROM USERS WHERE tg_id = {chat_id})").fetchone()[0]
            points_count = con.execute(f"SELECT points FROM USERS WHERE tg_id = {chat_id}").fetchone()[0]
        message = f"Кол-во аукционов: {auction_count}" \
                  f"\nКол-во ставок: {bets_count}" \
                  f"\nКол-во выигранных ставок: {wins_count}" \
                  f"\nКол-во баллов: {points_count}"
        bot.edit_message_text(message_id=message_id, chat_id=chat_id, text=message, reply_markup=return_button)

    if flag == "h":
        message = "Свяжитесь с нами, если у вас возникли вопросы @PathFree\n\nУдачных торгов и выгодных покупок."
        bot.edit_message_text(message_id=message_id, chat_id=chat_id, text=message, reply_markup=return_button)

    if flag == "a":
        bot.answer_callback_query(callback_query_id=call.id, text="Делая ставку участник подтверждает желание и возможность выкупить лот, "
                                           "случае невыкупа лота в течении 3х суток участник блокируется!", show_alert=True)
    if flag == "c":
        lot_id = call.data[1:]
        with con:
            end_time = con.execute(f"SELECT end_time FROM LOTS WHERE id = {lot_id}").fetchone()[0]
        now = datetime.now()
        end_time = datetime.strptime(end_time, "%d.%m.%Y %H:%M")
        delta = end_time - now
        hours = delta.seconds // 3600
        minutes = delta.seconds % 3600 // 60
        secs = delta.seconds % 3600 % 60
        bot.answer_callback_query(callback_query_id=call.id, text=f"Осталось {hours} часов {minutes} минут {secs} секунд")

    if flag == "g" or flag == "+" or flag == "u":
        data = call.data.split(" ")
        lot_id = data[1]
        now = datetime.now().strftime("%d.%m.%Y %H:%M")
        with con:
            seller_id = con.execute(f"SELECT seller_id FROM LOTS WHERE id = {lot_id}").fetchone()[0]
            buyer_id = con.execute(f"SELECT id FROM USERS WHERE tg_id = {chat_id}").fetchone()[0]
            current_bet = con.execute(f"SELECT MAX(current_bet) FROM TRADE_HIST WHERE lot_id = {lot_id}").fetchone()[0]
            if not current_bet:
                current_bet = con.execute(f"SELECT start_price FROM LOTS WHERE id = {lot_id}").fetchone()[0]
            print(current_bet)
            if flag == "g":
                con.execute(f"INSERT INTO TRADE_HIST WHERE (date_time, seller_id, buyer_id, current_bet, lot_id)"
                            f"VALUES ('{now}', {seller_id}, {buyer_id}, {current_bet}, {lot_id})")
                bot.answer_callback_query(callback_query_id=call.id,
                                          text=f"Ваша ставка принята.")
            if flag == "+":
                con.execute(f"INSERT INTO TRADE_HIST (date_time, seller_id, buyer_id, current_bet, lot_id)"
                            f"VALUES ('{now}', {seller_id}, {buyer_id}, {int(current_bet) + int(data[2])}, {lot_id})")
                bot.answer_callback_query(callback_query_id=call.id,
                                          text=f"Ваша ставка принята.")
            if flag == "u":
                auction_count = con.execute(f"SELECT COUNT(DISTINCT(lot_id)) FROM TRADE_HIST "
                                            f"WHERE buyer_id = (SELECT id FROM USERS WHERE tg_id = {chat_id})").fetchone()[0]
                bets_count = con.execute(f"SELECT COUNT(current_bet) FROM TRADE_HIST "
                                         f"WHERE buyer_id = (SELECT id FROM USERS WHERE tg_id = {chat_id})").fetchone()[0]
                if int(auction_count) < 5 or bets_count < 10:
                    bot.send_message(chat_id, "Для использовалния авто-ставки нужно соответствовать следующим условиям:\n"
                                              "1)Принять участие в минимум 5 лотах и дождаться их завершения\n"
                                              "2)Совершить как минимум 10 ставок", reply_markup=return_button)


print("Ready")
bot.infinity_polling()
