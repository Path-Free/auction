from PyQt5 import QtCore, QtWidgets
import sqlite3 as sl
from functools import partial
con = sl.connect("auction.db")

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(1061, 381)
        self.tableWidget = QtWidgets.QTableWidget(Dialog)
        self.tableWidget.setGeometry(QtCore.QRect(10, 50, 1041, 321))
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.verticalHeader().setVisible(False)
        self.tableWidget.setSelectionBehavior(QtWidgets.QTableView.SelectRows)
        self.tableWidget.setSortingEnabled(1)
        self.table_gen()
        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(10, 10, 131, 31))
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(180, 10, 141, 31))
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_4 = QtWidgets.QPushButton(Dialog)
        self.pushButton_4.setGeometry(QtCore.QRect(560, 10, 131, 31))
        self.pushButton_4.setObjectName("pushButton_4")
        self.pushButton_5 = QtWidgets.QPushButton(Dialog)
        self.pushButton_5.setGeometry(QtCore.QRect(920, 10, 131, 31))
        self.pushButton_5.setObjectName("pushButton_5")
        self.pushButton_6 = QtWidgets.QPushButton(Dialog)
        self.pushButton_6.setGeometry(QtCore.QRect(750, 10, 131, 31))
        self.pushButton_6.setObjectName("pushButton_6")

        QtCore.QMetaObject.connectSlotsByName(Dialog)

        Dialog.setWindowTitle("Лоты")
        self.pushButton.setText("Добавить")
        self.pushButton_2.setText("Удалить")
        self.pushButton_4.setText("Возобновить")
        self.pushButton_5.setText("Пожаловаться")
        self.pushButton_6.setText("История")

        self.pushButton.clicked.connect(partial(self.add_lot, Dialog))
        self.pushButton_2.clicked.connect(self.delete)
        self.pushButton_4.clicked.connect(partial(self.resume, Dialog))
        self.pushButton_6.clicked.connect(partial(self.history, Dialog))
        self.pushButton.clicked.connect()


    def table_gen(self):
        try:
            with con:
                columns_info = con.execute(f"PRAGMA table_info(LOTS);").fetchall()
                table_list = con.execute(f"SELECT * FROM LOTS WHERE seller_id = {self.id}").fetchall()
            column_names = []
            for x in columns_info:
                column_names.append(x[1])
            self.tableWidget.setColumnCount(len(table_list[0]))
            self.tableWidget.setRowCount(len(table_list))
            self.tableWidget.setHorizontalHeaderLabels(column_names)
            for i in range(0, len(table_list)):
                for j in range(0, len(table_list[0])):
                    item = QtWidgets.QTableWidgetItem
                    self.tableWidget.setItem(i, j, item(str(table_list[i][j])))
        except:
            pass