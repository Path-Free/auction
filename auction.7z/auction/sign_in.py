from PyQt5 import QtCore, QtGui, QtWidgets
from functools import partial
import time
import sqlite3 as sl
import admin, support, superadmin
con = sl.connect("auction.db")


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(400, 300)
        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(210, 230, 141, 41))
        font = QtGui.QFont()
        font.setPointSize(18)
        self.pushButton.setFont(font)
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(40, 230, 141, 41))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setObjectName("pushButton_2")
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(40, 20, 311, 31))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.lineEdit = QtWidgets.QLineEdit(Dialog)
        self.lineEdit.setGeometry(QtCore.QRect(40, 50, 311, 31))
        self.lineEdit.setObjectName("lineEdit")
        self.lineEdit_2 = QtWidgets.QLineEdit(Dialog)
        self.lineEdit_2.setGeometry(QtCore.QRect(40, 140, 311, 31))
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(40, 110, 311, 31))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")

        self.label_4 = QtWidgets.QLabel(Dialog)
        self.label_4.setVisible(False)
        self.label_4.setGeometry(QtCore.QRect(110, 10, 171, 20))
        self.label_4.setObjectName("label_4")

        QtCore.QMetaObject.connectSlotsByName(Dialog)

        Dialog.setWindowTitle("Авторизация")
        self.pushButton.setText("Войти")
        self.pushButton_2.setText("Регистрация")
        self.label.setText("Логин")
        self.label_2.setText("Пароль")

        self.label_4.setText("Такой логин уже зарегистрирован.")

        self.pushButton.clicked.connect(partial(self.check, Dialog))
        self.pushButton_2.clicked.connect(self.register)

    def check(self, Dialog):
        login = self.lineEdit.text()
        password = self.lineEdit_2.text()
        try:
            with con:
                data = con.execute(f"SELECT password FROM ADMINS WHERE login = '{login}'").fetchone()[0]
                level = con.execute(f"SELECT level FROM ADMINS WHERE login = '{login}'").fetchone()[0]
                id = con.execute(f"SELECT id FROM ADMINS WHERE login = '{login}'").fetchone()[0]
            if password == data:
                self.enter_account(level, id, Dialog)
            else:
                self.label_3 = QtWidgets.QLabel(Dialog)
                self.label_3.setGeometry(QtCore.QRect(110, 10, 171, 20))
                self.label_3.setObjectName("label_3")
                self.label_3.setText("Неправильный логин или пароль.")
        except:
            self.label_5 = QtWidgets.QLabel(Dialog)
            self.label_5.setGeometry(QtCore.QRect(110, 10, 171, 20))
            self.label_5.setObjectName("label_5")
            self.label_5.setText("Такого логина не существует.")

    def register(self):
        login = self.lineEdit.text()
        password = self.lineEdit_2.text()
        with con:
            data = con.execute(f"SELECT EXISTS (SELECT id FROM ADMINS WHERE login = '{login}')").fetchone()[0]
            if data:
                self.label_4.setVisible(True)
                time.sleep(2)
                self.label_4.setVisible(False)
            else:
                con.execute(f"INSERT INTO ADMINS (login, password) VALUES ('{login}', '{password}')")

    def enter_account(self, level, id, Dialog):
        Dialog.close()
        New_Dialog = QtWidgets.QDialog()
        if level == 0:
            ui_2 = admin.Ui_Dialog()
        elif level == 1:
            ui_2 = support.Ui_Dialog()
        elif level == 2:
            ui_2 = superadmin.Ui_Dialog()
        ui_2.id = id
        ui_2.setupUi(New_Dialog)
        New_Dialog.show()
        New_Dialog.exec_()


import sys
app = QtWidgets.QApplication(sys.argv)
Dialog = QtWidgets.QDialog()
ui = Ui_Dialog()
ui.setupUi(Dialog)
Dialog.show()
sys.exit(app.exec_())
