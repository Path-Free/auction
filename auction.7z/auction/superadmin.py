from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(151, 215)
        font = QtGui.QFont()
        font.setPointSize(20)
        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(10, 10, 131, 41))
        self.pushButton.setFont(font)
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(10, 60, 131, 41))
        self.pushButton_2.setFont(font)
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_3 = QtWidgets.QPushButton(Dialog)
        self.pushButton_3.setGeometry(QtCore.QRect(10, 110, 131, 41))
        self.pushButton_3.setFont(font)
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_4 = QtWidgets.QPushButton(Dialog)
        self.pushButton_4.setGeometry(QtCore.QRect(10, 160, 131, 41))
        self.pushButton_4.setFont(font)
        self.pushButton_4.setObjectName("pushButton_4")

        QtCore.QMetaObject.connectSlotsByName(Dialog)

        Dialog.setWindowTitle("Dialog")
        self.pushButton.setText("Лоты")
        self.pushButton_2.setText("Жалобы")
        self.pushButton_3.setText("Админы")
        self.pushButton_4.setText("Пользователи")



