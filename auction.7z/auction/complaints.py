from PyQt5 import QtCore,QtWidgets
import sqlite3 as sl
con = sl.connect("auction.db")


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(592, 302)
        self.tableWidget = QtWidgets.QTableWidget(Dialog)
        self.tableWidget.setGeometry(QtCore.QRect(10, 10, 571, 281))
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.verticalHeader().setVisible(False)
        self.tableWidget.setSelectionBehavior(QtWidgets.QTableView.SelectRows)
        self.tableWidget.setSortingEnabled(1)
        self.table_gen()

        QtCore.QMetaObject.connectSlotsByName(Dialog)
        Dialog.setWindowTitle("Жалобы")

    def table_gen(self):
        try:
            with con:
                columns_info = con.execute(f"PRAGMA table_info(COMPLAINTS);").fetchall()
                table_list = con.execute(f"SELECT * FROM COMPLAINTS").fetchall()
            column_names = []
            for x in columns_info:
                column_names.append(x[1])
            self.tableWidget.setColumnCount(len(table_list[0]))
            self.tableWidget.setRowCount(len(table_list))
            self.tableWidget.setHorizontalHeaderLabels(column_names)
            for i in range(0, len(table_list)):
                for j in range(0, len(table_list[0])):
                    item = QtWidgets.QTableWidgetItem
                    self.tableWidget.setItem(i, j, item(str(table_list[i][j])))
        except:
            pass
