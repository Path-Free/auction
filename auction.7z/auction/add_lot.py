from PyQt5 import QtCore, QtWidgets
import sqlite3 as sl
import admin_lots
from functools import partial
con = sl.connect("auction.db")


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(400, 300)
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(20, 20, 91, 16))
        self.label.setObjectName("label")
        self.spinBox = QtWidgets.QSpinBox(Dialog)
        self.spinBox.setGeometry(QtCore.QRect(20, 41, 151, 21))
        self.spinBox.setObjectName("spinBox")
        self.spinBox.setMaximum(10000000)
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(20, 69, 91, 16))
        self.label_2.setObjectName("label_2")
        self.lineEdit = QtWidgets.QLineEdit(Dialog)
        self.lineEdit.setGeometry(QtCore.QRect(20, 90, 151, 20))
        self.lineEdit.setObjectName("lineEdit")
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(20, 120, 91, 16))
        self.label_3.setObjectName("label_3")
        self.dateTimeEdit = QtWidgets.QDateTimeEdit(Dialog)
        self.dateTimeEdit.setGeometry(QtCore.QRect(20, 140, 151, 22))
        self.dateTimeEdit.setObjectName("dateTimeEdit")
        self.label_4 = QtWidgets.QLabel(Dialog)
        self.label_4.setGeometry(QtCore.QRect(20, 170, 91, 16))
        self.label_4.setObjectName("label_4")
        self.PlainTextEdit = QtWidgets.QPlainTextEdit(Dialog)
        self.PlainTextEdit.setGeometry(QtCore.QRect(20, 190, 151, 71))
        self.PlainTextEdit.setObjectName("textEdit")
        self.comboBox = QtWidgets.QComboBox(Dialog)
        self.comboBox.setGeometry(QtCore.QRect(210, 40, 151, 22))
        self.comboBox.setObjectName("comboBox")
        self.comboBox.addItem("Ювелирный")
        self.comboBox.addItem("Исторический")
        self.comboBox.addItem("Стандартный")
        self.label_5 = QtWidgets.QLabel(Dialog)
        self.label_5.setGeometry(QtCore.QRect(210, 20, 91, 16))
        self.label_5.setObjectName("label_5")
        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(210, 140, 151, 23))
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(210, 190, 151, 41))
        self.pushButton_2.setObjectName("pushButton_2")
        self.dateTimeEdit_2 = QtWidgets.QDateTimeEdit(Dialog)
        self.dateTimeEdit_2.setGeometry(QtCore.QRect(210, 240, 151, 22))
        self.dateTimeEdit_2.setObjectName("dateTimeEdit_2")

        QtCore.QMetaObject.connectSlotsByName(Dialog)

        Dialog.setWindowTitle("Добавить лот")
        self.label.setText("Начальная цена")
        self.label_2.setText("Геолокация")
        self.label_3.setText("Конец торгов")
        self.label_4.setText("Описание")
        self.label_5.setText("Тип")
        self.pushButton.setText("Опубликовать")
        self.pushButton_2.setText("Отложенная\nпубликация")

        try:
            if self.lot_info:
                print(self.lot_info)
                self.spinBox.setValue(self.lot_info[6])
                self.lineEdit.setText(self.lot_info[2])
                self.PlainTextEdit.setPlainText(self.lot_info[3])
                self.spinBox.setValue(int(self.lot_info[7]) - 1)
        except:
            pass

        self.pushButton.clicked.connect(partial(self.submit, Dialog))
        self.pushButton_2.clicked.connect(partial(self.submit_later, Dialog))

    def submit(self, Dialog):
        type = self.comboBox.currentText()
        start_price = self.spinBox.text()
        geo = self.lineEdit.text()
        end_time = self.dateTimeEdit.text()
        description = self.PlainTextEdit.toPlainText()
        seller_id = self.id
        with con:
            type_id = con.execute(f"SELECT id FROM TYPES WHERE name = '{type}'").fetchone()[0]
            con.execute(f"INSERT INTO LOTS (seller_id, geo, description, end_time, start_price, type_id) "
                        f"VALUES ({seller_id}, '{geo}', '{description}', '{end_time}', {start_price}, {type_id})")
            lot_id = con.execute("SELECT last_insert_rowid()").fetchone()[0]
            admin_info = con.execute(f"SELECT info FROM ADMINS WHERE id = {self.id}").fetchone()[0]
        Dialog.close()
        self.Dialog.close()
        New_Dialog = QtWidgets.QDialog()
        ui_2 = admin_lots.Ui_Dialog()
        ui_2.id = self.id
        ui_2.setupUi(New_Dialog)
        New_Dialog.show()
        New_Dialog.exec_()

    def submit_later(self, Dialog):
        type = self.comboBox.currentText()
        start_price = self.spinBox.text()
        geo = self.lineEdit.text()
        start_price = self.dateTimeEdit_2.text()
        end_time = self.dateTimeEdit.text()
        description = self.PlainTextEdit.toPlainText()
        seller_id = self.id
        with con:
            type_id = con.execute(f"SELECT id FROM TYPES WHERE name = '{type}'").fetchone()[0]
            con.execute(f"INSERT INTO LOTS (seller_id, geo, description, start_time, end_time, start_price, type_id) "
                        f"VALUES ({seller_id}, '{geo}', '{description}', '{start_price}', '{end_time}', {start_price}, {type_id})")
            lot_id = con.execute("SELECT last_insert_rowid()").fetchone()[0]
            admin_info = con.execute(f"SELECT info FROM ADMINS WHERE id = {self.id}").fetchone()[0]
        Dialog.close()
        self.Dialog.close()
        New_Dialog = QtWidgets.QDialog()
        ui_2 = admin_lots.Ui_Dialog()
        ui_2.id = self.id
        ui_2.setupUi(New_Dialog)
        New_Dialog.show()
        New_Dialog.exec_()