from PyQt5 import QtCore, QtGui, QtWidgets
import sqlite3 as sl
import  admin_lots, fin_hist
con = sl.connect("auction.db")


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(151, 152)
        self.pushButton_2 = QtWidgets.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(10, 50, 131, 41))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(10, 100, 131, 41))
        self.pushButton.setFont(font)
        self.pushButton.setObjectName("pushButton")
        self.lineEdit = QtWidgets.QLineEdit(Dialog)
        self.lineEdit.setGeometry(QtCore.QRect(10, 10, 131, 31))
        self.lineEdit.setFont(font)
        self.lineEdit.setObjectName("lineEdit")

        QtCore.QMetaObject.connectSlotsByName(Dialog)

        Dialog.setWindowTitle("ЛК Администратора")
        self.pushButton_2.setText("Финансы")
        self.pushButton.setText("Лоты")

        with con:
            balance = con.execute(f"SELECT balance FROM ADMINS WHERE id = {self.id}").fetchone()[0]
        self.lineEdit.setText(f"{balance}₽")


        self.pushButton.clicked.connect(self.lots)
        self.pushButton_2.clicked.connect(self.fin_hist)

    def lots(self):
        New_Dialog = QtWidgets.QDialog()
        ui_2 = admin_lots.Ui_Dialog()
        ui_2.id = self.id
        ui_2.setupUi(New_Dialog)
        New_Dialog.show()
        New_Dialog.exec_()

    def fin_hist(self):
        New_Dialog = QtWidgets.QDialog()
        ui_2 = fin_hist.Ui_Dialog()
        ui_2.id = self.id
        ui_2.setupUi(New_Dialog)
        New_Dialog.show()
        New_Dialog.exec_()


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())