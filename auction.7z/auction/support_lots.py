from PyQt5 import QtCore, QtWidgets
import sqlite3 as sl
con = sl.connect("auction.db")


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(1061, 300)
        self.tableWidget = QtWidgets.QTableWidget(Dialog)
        self.tableWidget.setGeometry(QtCore.QRect(10, 50, 1041, 241))
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.verticalHeader().setVisible(False)
        self.tableWidget.setSelectionBehavior(QtWidgets.QTableView.SelectRows)
        self.tableWidget.setSortingEnabled(1)
        self.table_gen()
        self.pushButton_4 = QtWidgets.QPushButton(Dialog)
        self.pushButton_4.setGeometry(QtCore.QRect(10, 10, 91, 31))
        self.pushButton_4.setObjectName("pushButton_4")
        self.pushButton_5 = QtWidgets.QPushButton(Dialog)
        self.pushButton_5.setGeometry(QtCore.QRect(110, 10, 91, 31))
        self.pushButton_5.setObjectName("pushButton_5")

        QtCore.QMetaObject.connectSlotsByName(Dialog)

        Dialog.setWindowTitle("Проверка лотов")
        self.pushButton_4.setText("Одобрить")
        self.pushButton_5.setText("Блокировать")
        self.pushButton_4.clicked.connect(self.approve)
        self.pushButton_5.clicked.connect(self.deny)

    def table_gen(self):
        try:
            with con:
                columns_info = con.execute(f"PRAGMA table_info(LOTS);").fetchall()
                table_list = con.execute(f"SELECT * FROM LOTS").fetchall()
            column_names = []
            for x in columns_info:
                column_names.append(x[1])
            self.tableWidget.setColumnCount(len(table_list[0]))
            self.tableWidget.setRowCount(len(table_list))
            self.tableWidget.setHorizontalHeaderLabels(column_names)
            for i in range(0, len(table_list)):
                for j in range(0, len(table_list[0])):
                    item = QtWidgets.QTableWidgetItem
                    self.tableWidget.setItem(i, j, item(str(table_list[i][j])))
        except:
            pass

    def approve(self):
        try:
            selected = self.tableWidget.selectedItems()[0].row()
            lot_id = self.tableWidget.item(selected, 0).text()
            with con:
                con.execute(f"UPDATE LOTS SET status_id = 2 WHERE id = {lot_id} AND status_id = 1 OR status_id = 7")
            self.table_gen()
        except:
            pass

    def deny(self):
        try:
            selected = self.tableWidget.selectedItems()[0].row()
            lot_id = self.tableWidget.item(selected, 0).text()
            with con:
                con.execute(f"UPDATE LOTS SET status_id = 7 WHERE id = {lot_id}")
            self.table_gen()
        except:
            pass