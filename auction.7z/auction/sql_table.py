import sqlite3 as sl

con = sl.connect('auction.db')

with con:
    con.execute("""
        CREATE TABLE IF NOT EXISTS USERS (
            id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            strikes INTEGER DEFAULT 0,
            balance INTEGER DEFAULT 0,
            points INTEGER DEFAULT 0,
            name TEXT,
            tg_id INTEGER,
            unique(tg_id)
        );
    """)
    con.execute("""
        CREATE TABLE IF NOT EXISTS ADMINS (
            id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            level INTEGER DEFAULT 0,
            login TEXT,
            password TEXT,
            balance INTEGER DEFAULT 0,
            info TEXT
        );
    """)
    con.execute("""
        CREATE TABLE IF NOT EXISTS LOTS (
            id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            seller_id INTEGER,
            geo TEXT,
            description TEXT,
            start_time TEXT,
            end_time TEXT,
            start_price INTEGER,
            type_id INTEGER DEFAULT 0,
            status_id INTEGER DEFAULT 1
        );
    """)
    con.execute("""
        CREATE TABLE IF NOT EXISTS TYPES (
            id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            name TEXT
        );
    """)
    con.execute("""
        CREATE TABLE IF NOT EXISTS STATUSES (
            id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            name TEXT
        );
    """)
    con.execute("""
        CREATE TABLE IF NOT EXISTS FIN_HIST (
            id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            date_time TEXT,
            operation_id INTEGER,
            sum INTEGER,
            receiver_id INTEGER,
            sender_id INTEGER
        );
    """)
    con.execute("""
        CREATE TABLE IF NOT EXISTS OPERATIONS (
            id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            name TEXT
        );
    """)
    con.execute("""
        CREATE TABLE IF NOT EXISTS TRADE_HIST (
            id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            date_time TEXT,
            seller_id INTEGER,
            buyer_id INTEGER,
            current_bet INTEGER,
            lot_id INTEGER
        );
    """)
    con.execute("""
        CREATE TABLE IF NOT EXISTS COMPLAINTS (
            id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            admin_id INTEGER,
            text TEXT,
            date_time TEXT
        );
    """)
    con.execute("""
        CREATE TABLE IF NOT EXISTS STRIKES (
            id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            admin_id INTEGER,
            text TEXT,
            date_time TEXT
        );
    """)

# sql_insert = "INSERT OR IGNORE INTO  (name) values()"
# with con:
#     con.execute(sql_insert, [])


with con:
    con.execute("INSERT OR IGNORE INTO OPERATIONS (name) VALUES ('+')")
    con.execute("INSERT OR IGNORE INTO OPERATIONS (name) VALUES ('-')")
    con.execute("INSERT OR IGNORE INTO TYPES (name) VALUES ('Стандартный')")
    con.execute("INSERT OR IGNORE INTO TYPES (name) VALUES ('Ювелирный')")
    con.execute("INSERT OR IGNORE INTO TYPES (name) VALUES ('Исторический')")
    con.execute("INSERT OR IGNORE INTO STATUSES (name) VALUES ('В ожидании')")
    con.execute("INSERT OR IGNORE INTO STATUSES (name) VALUES ('Одобрен')")
    con.execute("INSERT OR IGNORE INTO STATUSES (name) VALUES ('Опубликован')")
    con.execute("INSERT OR IGNORE INTO STATUSES (name) VALUES ('Продан')")
    con.execute("INSERT OR IGNORE INTO STATUSES (name) VALUES ('Торги завершены')")
    con.execute("INSERT OR IGNORE INTO STATUSES (name) VALUES ('Оплачен')")
    con.execute("INSERT OR IGNORE INTO STATUSES (name) VALUES ('Блокирован')")
    con.execute("INSERT OR IGNORE INTO COMPLAINTS (user_id, admin_id, text, date_time) VALUES (1, 1, 'Дубина, не может своей башкой придумать как сделать отложенную публикацию', '26.07.2023 15:30')")

# with con:
#     data = con.execute("SELECT * FROM CATEGORIES").fetchall()
#     print(data)

    # data = con.execute("PRAGMA table_info(CLIENTS);").fetchall()
    # for x in data:
    #     print(x[1])