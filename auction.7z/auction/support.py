from PyQt5 import QtCore, QtGui, QtWidgets
import support_lots, complaints, strikes


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(431, 62)
        font = QtGui.QFont()
        font.setPointSize(20)
        self.pushButton_3 = QtWidgets.QPushButton(Dialog)
        self.pushButton_3.setGeometry(QtCore.QRect(290, 10, 131, 41))
        self.pushButton_3.setFont(font)
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_2 = QtWidgets.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(150, 10, 131, 41))
        self.pushButton_2.setFont(font)
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(10, 10, 131, 41))
        self.pushButton.setFont(font)
        self.pushButton.setObjectName("pushButton")
        QtCore.QMetaObject.connectSlotsByName(Dialog)
        Dialog.setWindowTitle("ЛК Поддержки")
        self.pushButton_2.setText("Жалобы")
        self.pushButton_3.setText("Страйки")
        self.pushButton.setText("Лоты")
        self.pushButton.clicked.connect(self.lots)
        self.pushButton_2.clicked.connect(self.complaints)
        self.pushButton_3.clicked.connect(self.strikes)

    def lots(self):
        New_Dialog = QtWidgets.QDialog()
        ui_2 = support_lots.Ui_Dialog()
        ui_2.id = self.id
        ui_2.setupUi(New_Dialog)
        New_Dialog.show()
        New_Dialog.exec_()

    def complaints(self):
        New_Dialog = QtWidgets.QDialog()
        ui_2 = complaints.Ui_Dialog()
        ui_2.id = self.id
        ui_2.setupUi(New_Dialog)
        New_Dialog.show()
        New_Dialog.exec_()

    def strikes(self):
        New_Dialog = QtWidgets.QDialog()
        ui_2 = strikes.Ui_Dialog()
        ui_2.id = self.id
        ui_2.setupUi(New_Dialog)
        New_Dialog.show()
        New_Dialog.exec_()